package com.javarush.test.level11.lesson08.task05;

/* Добавь недостающие переменные
Посмотри внимательно на методы и добавь недостающие переменные.
*/

public class Solution
{
    public static void main(String[] args)
    {
    }

    public class Cat
    {

        private int weight;
        private int speed;
        private int age;
        private String name;

        public Cat(String name, int age, int weight)
        {

        }

        public String getName()
        {
            return null;
        }

        public int getAge()
        {
            return 0;
        }

        public void setWeight(int weight)
        {

        }

        public void setSpeed(int speed)
        {

        }
    }
}
