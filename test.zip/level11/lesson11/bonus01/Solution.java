package com.javarush.test.level11.lesson11.bonus01;

/* Нужно исправить программу, чтобы компилировалась и работала
Исправь наследование в классах: (классы Cat, Dog, Pet, House, Airplane).
*/

public class Solution
{
    public static void main(String[] args)
    {
    }

    public class Pet
    {

    }

    public class Cat extends Pet
    {

    }

    public class Dog extends Pet
    {

    }

    public class House
    {

    }

    public class Airplane
    {

    }
}
